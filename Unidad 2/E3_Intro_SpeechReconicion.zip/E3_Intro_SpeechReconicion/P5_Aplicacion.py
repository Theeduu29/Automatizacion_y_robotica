import webbrowser

import speech_recognition as sr
r = sr.Recognizer()
#audio_file = sr.AudioFile('Audios/audio1.wav')
audio_file = sr.AudioFile('Audios/audio_file.wav')
try:
    with audio_file as source:
        print("Procesando el audio...")
        audio = r.record(source)

    var = r.recognize_google(audio,language="es-MX", show_all=False)
    print("Mensaje: " ) #personalized
    print(var)

    palabras = str(var).split()
    print("Palabras reconocidas:", palabras)

    # Ejemplo de lógica para palabras clave
    if "abrir" in palabras and "navegador" in palabras:
        print("Abriendo navegador...")
        webbrowser.open("https://www.google.com")

    else:
        print("No se reconoció un comando específico.")


except sr.UnknownValueError as e:
    print("Unknown Value Error", e)
except sr.RequestError as e:
    print("Request Error: ".format(e))
except Exception as ex:
    print(ex)

